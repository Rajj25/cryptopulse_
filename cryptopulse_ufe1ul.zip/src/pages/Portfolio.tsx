export function Portfolio() {
  return <h1 className="text-white p-4">Portfolio Coming Soon</h1>;
}
