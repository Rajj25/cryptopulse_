export function Signals() {
  return <h1 className="text-white p-4">Signals Coming Soon</h1>;
}
