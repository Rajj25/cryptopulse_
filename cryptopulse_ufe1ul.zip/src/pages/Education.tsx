export function Education() {
  return <h1 className="text-white p-4">Education Coming Soon</h1>;
}
