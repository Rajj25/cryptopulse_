export function Analysis() {
  return <h1 className="text-white p-4">Analysis Coming Soon</h1>;
}
