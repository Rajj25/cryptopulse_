import React, { useEffect, useState } from "react";

export function Dashboard() {
  const [prices, setPrices] = useState<any>({});

  useEffect(() => {
    fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=injective-protocol,bitcoin,ethereum,solana&vs_currencies=usd&include_24hr_change=true"
    )
      .then((res) => res.json())
      .then((data) => setPrices(data));
  }, []);

  const coins = [
    { id: "injective-protocol", name: "Injective (INJ)" },
    { id: "bitcoin", name: "Bitcoin (BTC)" },
    { id: "ethereum", name: "Ethereum (ETH)" },
    { id: "solana", name: "Solana (SOL)" },
  ];

  return (
    <div className="p-4 text-white">
      <h1 className="text-2xl font-bold mb-4">CryptoPulse Dashboard</h1>

      <h2 className="text-xl mb-3">Live Market</h2>

      <div className="space-y-3">
        {coins.map((coin) => {
          const item = prices[coin.id];

          return (
            <div
              key={coin.id}
              className="bg-zinc-900 rounded-lg p-4 flex justify-between items-center"
            >
              <p className="font-medium">{coin.name}</p>

              {item ? (
                <div className="text-right">
                  <p className="text-lg font-semibold">${item.usd.toFixed(2)}</p>
                  <p
                    className={
                      item.usd_24h_change > 0 ? "text-green-400" : "text-red-400"
                    }
                  >
                    {item.usd_24h_change.toFixed(2)}%
                  </p>
                </div>
              ) : (
                <p className="text-gray-500">Loading...</p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
