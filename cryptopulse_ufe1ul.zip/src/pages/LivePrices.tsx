export function LivePrices() {
  return <h1 className="text-white p-4">Live Prices Coming Soon</h1>;
}
