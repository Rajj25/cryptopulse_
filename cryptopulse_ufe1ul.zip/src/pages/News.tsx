export function News() {
  return <h1 className="text-white p-4">News Coming Soon</h1>;
}
