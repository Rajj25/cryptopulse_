import { useMemo, useState, useEffect } from "react";
import { ChainId, EvmChainId } from "@injectivelabs/ts-types";
import { Network, getNetworkEndpoints } from "@injectivelabs/networks";
import { MsgBroadcaster } from "@injectivelabs/wallet-core";
import { Wallet } from "@injectivelabs/wallet-base";
import { getInjectiveAddress, MsgSend } from "@injectivelabs/sdk-ts";
import { BigNumberInBase } from "@injectivelabs/utils";
import { WalletStrategy } from "@injectivelabs/wallet-strategy";

// Using Testnet for development safety
const NETWORK = Network.Testnet;
const CHAIN_ID = ChainId.Testnet;
const EVM_CHAIN_ID = EvmChainId.Testnet;

const endpoints = getNetworkEndpoints(NETWORK);

const walletStrategy = new WalletStrategy({
  chainId: CHAIN_ID,
  evmOptions: {
    evmChainId: EVM_CHAIN_ID,
  },
  strategies: {},
});

const msgBroadcaster = new MsgBroadcaster({
  walletStrategy,
  simulateTx: true,
  network: NETWORK,
  endpoints: endpoints,
  gasBufferCoefficient: 1.1,
});

export function useInjectiveWallet() {
  const [address, setAddress] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const injectiveAddress = useMemo(() => {
    if (address) {
      try {
        return getInjectiveAddress(address);
      } catch (e) {
        return "";
      }
    } else {
      return "";
    }
  }, [address]);

  async function connect(wallet: Wallet) {
    setIsLoading(true);
    setError(null);
    try {
      walletStrategy.setWallet(wallet);
      const addresses = await walletStrategy.getAddresses();
      if (addresses && addresses.length > 0) {
        setAddress(addresses[0]);
      }
    } catch (err: any) {
      console.error("Failed to connect wallet:", err);
      setError(err.message || "Failed to connect wallet");
    } finally {
      setIsLoading(false);
    }
  }

  function disconnect() {
    setAddress("");
    // Note: Most wallet adapters don't support programmatic disconnect
  }

  async function sendTransaction(destination: string, amount: number) {
    if (!injectiveAddress) return;
    setIsLoading(true);
    setError(null);

    try {
      const msg = MsgSend.fromJSON({
        amount: {
          denom: "inj",
          amount: new BigNumberInBase(amount).toWei().toFixed(),
        },
        srcInjectiveAddress: injectiveAddress,
        dstInjectiveAddress: destination,
      });

      const txHash = await msgBroadcaster.broadcastV2({
        injectiveAddress,
        msgs: [msg],
      });
      
      return txHash;
    } catch (err: any) {
      console.error("Transaction failed:", err);
      setError(err.message || "Transaction failed");
      throw err;
    } finally {
      setIsLoading(false);
    }
  }

  return {
    address,
    injectiveAddress,
    connect,
    disconnect,
    sendTransaction,
    isLoading,
    error,
  };
}
