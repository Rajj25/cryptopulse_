import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Zap, Shield, Globe } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 hero-glow pointer-events-none" />
      <div className="absolute top-0 right-0 w-1/2 h-full opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-l from-[#171717] to-transparent z-10" />
        <img 
          src="https://images.pexels.com/photos/8370752/pexels-photo-8370752.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
          alt="Abstract Digital Waves" 
          className="w-full h-full object-cover"
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-20 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 mb-6">
              <span className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse" />
              <span className="text-xs font-medium tracking-wide text-gray-300 uppercase">Live on Injective Mainnet</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
              The Pulse of <br />
              <span className="gradient-text">Decentralized</span> Finance
            </h1>
            
            <p className="text-lg text-gray-400 mb-8 max-w-lg leading-relaxed">
              Experience lightning-fast trading, zero gas fees, and unlimited access to cross-chain markets. Built for the future of finance.
            </p>

            <div className="flex flex-wrap gap-4">
              <button className="px-8 py-4 rounded-full bg-white text-black font-bold text-sm hover:bg-gray-200 transition-colors flex items-center gap-2">
                Start Trading <ArrowRight size={18} />
              </button>
              <button className="px-8 py-4 rounded-full bg-transparent border border-white/20 text-white font-bold text-sm hover:bg-white/5 transition-colors">
                View Documentation
              </button>
            </div>

            <div className="mt-12 grid grid-cols-3 gap-8 border-t border-white/10 pt-8">
              {[
                { label: 'Total Volume', value: '$12B+' },
                { label: 'Transactions', value: '450M+' },
                { label: 'Block Time', value: '0.8s' },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                  <div className="text-xs text-gray-500 uppercase tracking-wider">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="relative z-10 glass-panel rounded-3xl p-8 transform rotate-[-5deg] hover:rotate-0 transition-transform duration-500">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h3 className="text-xl font-bold">ETH/USDT</h3>
                  <p className="text-sm text-gray-400">Perpetual Market</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-mono font-bold text-[#10b981]">$3,452.80</div>
                  <div className="text-sm text-[#10b981]">+5.24%</div>
                </div>
              </div>
              
              <div className="h-48 w-full bg-gradient-to-b from-[#9E7FFF]/20 to-transparent rounded-xl border border-[#9E7FFF]/30 relative overflow-hidden mb-6">
                {/* Mock Chart Line */}
                <svg className="absolute bottom-0 left-0 w-full h-full" preserveAspectRatio="none">
                  <path d="M0,100 C100,80 200,120 300,60 S500,40 600,10 L600,200 L0,200 Z" fill="url(#grad)" />
                  <defs>
                    <linearGradient id="grad" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#9E7FFF" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#9E7FFF" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <path d="M0,100 C100,80 200,120 300,60 S500,40 600,10" fill="none" stroke="#9E7FFF" strokeWidth="3" />
                </svg>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <button className="py-3 rounded-xl bg-[#10b981]/10 text-[#10b981] font-bold hover:bg-[#10b981]/20 transition-colors">
                  Buy / Long
                </button>
                <button className="py-3 rounded-xl bg-[#ef4444]/10 text-[#ef4444] font-bold hover:bg-[#ef4444]/20 transition-colors">
                  Sell / Short
                </button>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-10 -right-10 w-24 h-24 bg-[#38bdf8] rounded-full blur-[60px] opacity-50" />
            <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-[#f472b6] rounded-full blur-[60px] opacity-40" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
