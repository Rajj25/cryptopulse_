import React from 'react';
import { Zap, Shield, Globe, Layers } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Execute trades with sub-second block times and instant finality."
  },
  {
    icon: Shield,
    title: "Bank-Grade Security",
    description: "Built on Cosmos SDK with robust security protocols and frequent audits."
  },
  {
    icon: Globe,
    title: "Cross-Chain Native",
    description: "Seamlessly bridge assets from Ethereum, Solana, and other major chains."
  },
  {
    icon: Layers,
    title: "Zero Gas Fees",
    description: "Experience true freedom with our innovative gas-free trading model."
  }
];

export function Features() {
  return (
    <section className="py-24 bg-[#171717] relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Why CryptoPulse?</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            We combine the best of centralized exchanges with the power of decentralized finance.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="p-6 rounded-2xl bg-[#262626] border border-white/5 hover:border-[#9E7FFF]/50 transition-all duration-300 group"
            >
              <div className="w-12 h-12 rounded-lg bg-white/5 flex items-center justify-center mb-6 group-hover:bg-[#9E7FFF] transition-colors">
                <feature.icon className="text-white" size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
