import React, { useState } from 'react';
import { Send, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';

interface TransactionSectionProps {
  address: string;
  injectiveAddress: string;
  onSend: (dest: string, amount: number) => Promise<any>;
  isLoading: boolean;
  error: string | null;
}

export function TransactionSection({ address, injectiveAddress, onSend, isLoading, error }: TransactionSectionProps) {
  const [destination, setDestination] = useState('');
  const [amount, setAmount] = useState('');
  const [successHash, setSuccessHash] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination || !amount) return;
    
    try {
      const hash = await onSend(destination, parseFloat(amount));
      setSuccessHash(hash?.txHash || "Transaction Sent");
      setDestination('');
      setAmount('');
    } catch (e) {
      // Error handled by parent
    }
  };

  if (!address) return null;

  return (
    <section className="py-20 bg-[#121212]">
      <div className="max-w-3xl mx-auto px-6">
        <div className="glass-panel rounded-3xl p-8 md:p-12 border border-[#9E7FFF]/20">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-full bg-[#9E7FFF]/20 flex items-center justify-center text-[#9E7FFF]">
              <Send size={24} />
            </div>
            <div>
              <h2 className="text-2xl font-bold">Quick Transfer</h2>
              <p className="text-gray-400 text-sm">Send INJ instantly to any address</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Destination Address</label>
              <input
                type="text"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="inj1..."
                className="w-full bg-[#171717] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#9E7FFF] transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Amount (INJ)</label>
              <input
                type="number"
                step="0.000001"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full bg-[#171717] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#9E7FFF] transition-colors"
              />
            </div>

            {error && (
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center gap-3 text-red-400">
                <AlertCircle size={20} />
                <span className="text-sm">{error}</span>
              </div>
            )}

            {successHash && (
              <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20 flex items-center gap-3 text-green-400">
                <CheckCircle2 size={20} />
                <div className="flex flex-col">
                  <span className="text-sm font-bold">Transaction Successful</span>
                  <span className="text-xs opacity-80 truncate max-w-[200px]">{successHash}</span>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading || !destination || !amount}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] text-white font-bold text-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="animate-spin" size={20} /> Processing...
                </>
              ) : (
                'Send Transaction'
              )}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-white/5">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-500">Your Address</span>
              <span className="font-mono text-gray-300 bg-[#171717] px-2 py-1 rounded">
                {injectiveAddress.slice(0, 10)}...{injectiveAddress.slice(-10)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
