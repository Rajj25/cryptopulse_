import React, { useState } from 'react';
import { Activity, Wallet as WalletIcon, Menu, X, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wallet } from "@injectivelabs/wallet-base";

interface HeaderProps {
  address: string;
  onConnect: (wallet: Wallet) => void;
  onDisconnect: () => void;
}

export function Header({ address, onConnect, onDisconnect }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const handleConnect = (wallet: Wallet) => {
    onConnect(wallet);
    setIsWalletModalOpen(false);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/5 bg-[#171717]/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#9E7FFF] to-[#38bdf8] flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Activity className="text-white" size={24} />
            </div>
            <span className="text-2xl font-bold tracking-tight font-serif">CryptoPulse</span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            {['Markets', 'Exchange', 'Governance', 'Developers'].map((item) => (
              <a key={item} href="#" className="text-sm font-medium text-gray-400 hover:text-white transition-colors">
                {item}
              </a>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-4">
            {address ? (
              <div className="flex items-center gap-3 bg-[#262626] border border-white/10 rounded-full pl-4 pr-2 py-1.5">
                <span className="text-sm font-mono text-gray-300">
                  {address.slice(0, 6)}...{address.slice(-4)}
                </span>
                <button 
                  onClick={onDisconnect}
                  className="p-1.5 hover:bg-red-500/20 hover:text-red-400 rounded-full transition-colors"
                >
                  <X size={14} />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsWalletModalOpen(true)}
                className="group relative px-6 py-2.5 rounded-full bg-white text-black font-medium text-sm overflow-hidden transition-all hover:shadow-[0_0_20px_rgba(255,255,255,0.3)]"
              >
                <span className="relative z-10 flex items-center gap-2">
                  Connect Wallet <ChevronRight size={16} className="group-hover:translate-x-0.5 transition-transform" />
                </span>
              </button>
            )}
          </div>

          <button className="md:hidden text-white" onClick={toggleMenu}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-[#171717] pt-24 px-6 md:hidden"
          >
            <div className="flex flex-col gap-6">
              {['Markets', 'Exchange', 'Governance', 'Developers'].map((item) => (
                <a key={item} href="#" className="text-2xl font-serif text-white/80 hover:text-white">
                  {item}
                </a>
              ))}
              <div className="h-px bg-white/10 my-4" />
              {!address && (
                <button
                  onClick={() => {
                    setIsWalletModalOpen(true);
                    setIsMenuOpen(false);
                  }}
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] text-white font-bold text-lg"
                >
                  Connect Wallet
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Wallet Modal */}
      <AnimatePresence>
        {isWalletModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsWalletModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-md bg-[#262626] border border-white/10 rounded-2xl p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-serif font-semibold">Connect Wallet</h3>
                <button onClick={() => setIsWalletModalOpen(false)} className="text-gray-400 hover:text-white">
                  <X size={20} />
                </button>
              </div>
              
              <div className="space-y-3">
                {[
                  { name: 'Metamask', icon: Wallet.Metamask },
                  { name: 'Keplr', icon: Wallet.Keplr },
                  { name: 'Leap', icon: Wallet.Leap },
                ].map((wallet) => (
                  <button
                    key={wallet.name}
                    onClick={() => handleConnect(wallet.icon)}
                    className="w-full flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/20 transition-all group"
                  >
                    <span className="font-medium">{wallet.name}</span>
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-[#9E7FFF] transition-colors">
                      <WalletIcon size={16} className="text-white" />
                    </div>
                  </button>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
