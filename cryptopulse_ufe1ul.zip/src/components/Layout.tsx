import React from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Home,
  Activity,
  Newspaper,
  BarChart2,
  Wallet,
  BookOpen,
} from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();

  const menu = [
    { to: "/", label: "Home", icon: <Home size={20} /> },
    { to: "/prices", label: "Prices", icon: <Activity size={20} /> },
    { to: "/news", label: "News", icon: <Newspaper size={20} /> },
    { to: "/signals", label: "Signals", icon: <BarChart2 size={20} /> },
    { to: "/portfolio", label: "Portfolio", icon: <Wallet size={20} /> },
    { to: "/education", label: "Learn", icon: <BookOpen size={20} /> },
  ];

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* CONTENT AREA */}
      <main className="flex-1 overflow-y-auto">{children}</main>

      {/* BOTTOM NAV BAR */}
      <nav className="bg-zinc-900 border-t border-zinc-800 p-2 flex justify-around">
        {menu.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className={`flex flex-col items-center text-xs ${
              location.pathname === item.to
                ? "text-blue-400"
                : "text-gray-400"
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}
